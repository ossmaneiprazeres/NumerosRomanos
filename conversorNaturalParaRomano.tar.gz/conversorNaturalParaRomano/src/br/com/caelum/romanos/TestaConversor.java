package br.com.caelum.romanos;

import java.lang.reflect.Method;

public class TestaConversor {

	public static void main(String[] args) {

		CalculaComReflection conversor = new CalculaComReflection();
		conversor.converteNaturalParaRomano(325);

	}

}
